import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <main className="home-page">
      <div className="home-background" aria-hidden="true">
        <Image
          src="/fondo-inicio.jpg"
          alt=""
          fill
          priority
          sizes="100vw"
          className="home-background-image"
        />
      </div>

      <div className="home-overlay" aria-hidden="true" />

      <div className="home-content">
        <header className="home-header">
          <div className="logo">🎮 Qva🇨🇺CHOP 🛒</div>
          <p className="subtitle">Tu tienda gaming</p>
        </header>

        <section className="home-hero">
          <div className="hero-badge">🔥 TIENDA GAMER</div>
          <h1>Compra tus juegos y recargas favoritas</h1>
          <p>
            Recargas rápidas, precios claros y entrega segura.
          </p>

          <Link href="/offers" className="hero-button">
            🎮 VER OFERTAS
          </Link>
        </section>

        <section className="home-product-preview">
          <Link href="/offers" className="product-link">
            <article className="store-product">
              <div className="product-image">
                <Image
                  src="/Images.jpeg"
                  alt="Diamonds Singapur"
                  fill
                  sizes="(max-width: 520px) 100vw, 520px"
                />
              </div>

              <div className="store-product-info">
                <h2>💎 Diamonds Singapur</h2>
                <p>100 💎 hasta 2200 💎 · Desde 1.01 USDT</p>
              </div>
            </article>
          </Link>
        </section>

        <footer className="footer">
          ⚡ Entrega rápida · 🛡️ Compra segura
        </footer>
      </div>
    </main>
  );
}
