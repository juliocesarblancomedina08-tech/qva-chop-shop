"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";

export default function SuccessPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState("");

  useEffect(() => {
    loadDelivery();
  }, []);

  async function loadDelivery() {
    try {
      const savedOrder = localStorage.getItem("qva_order");
      if (!savedOrder) throw new Error("No se encontró el pedido.");

      const order = JSON.parse(savedOrder);
      if (!order?.id || !order?.reference) {
        throw new Error("El pedido no es válido.");
      }

      const response = await fetch("/api/verify-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: Number(order.id),
          reference: order.reference,
        }),
        cache: "no-store",
      });

      const data = await response.json();
      if (!response.ok || !data?.ok || !data?.delivered) {
        throw new Error(
          data?.error || "El pago todavía no está confirmado."
        );
      }

      setResult({ ...data, orderData: order });
      localStorage.setItem("qva_payment_result", JSON.stringify(data));
      localStorage.removeItem("qva_cart");
      window.dispatchEvent(new Event("cartUpdated"));
    } catch (err) {
      console.error("SUCCESS_PAGE_ERROR:", err);
      setError(err?.message || "No se pudo cargar la entrega.");
    } finally {
      setLoading(false);
    }
  }

  async function copyCode(code) {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(code);
      setTimeout(() => setCopied(""), 1800);
    } catch {
      setError("No se pudo copiar el código.");
    }
  }

  if (loading) {
    return (
      <main className="success-page">
        <section className="success-card success-loading">
          <div className="success-check">✓</div>
          <h1>Verificando tu pago...</h1>
          <p>Estamos confirmando la transacción y preparando tu entrega.</p>
        </section>
      </main>
    );
  }

  if (error || !result) {
    return (
      <main className="success-page">
        <section className="success-card">
          <div className="success-error-icon">!</div>
          <h1>No pudimos completar la entrega</h1>
          <p>{error || "Intenta volver a la página de pago."}</p>
          <button className="success-primary-button" onClick={loadDelivery}>
            🔄 VOLVER A VERIFICAR
          </button>
          <Link href="/" className="success-back-link">← Volver a la tienda</Link>
        </section>
      </main>
    );
  }

  const codes = Array.isArray(result.codes) ? result.codes : [];
  const order = result.orderData;

  return (
    <main className="success-page">
      <div className="success-card">
        <header className="success-brand">
          <div className="success-brand-logo-wrap">
            <Image src="/qva-logo.png" alt="Qva CHOP" width={150} height={38} className="success-brand-logo" />
          </div>
          <div>
            <strong>🤖Qva🇨🇺CHOP🛒</strong>
            <span>TIENDA GAMER</span>
          </div>
        </header>

        <div className="success-divider" />

        <section className="success-status">
          <div className="success-check success-check-large">✓</div>
          <h1>Orden completada</h1>
          <p>Gracias por tu confianza</p>
          <span className="success-reference">Pedido: {order.reference}</span>
        </section>

        <section className="success-products">
          {codes.length === 0 ? (
            <div className="success-product-card">
              <div className="success-product-title">🎮 Producto digital</div>
              <p>Tu pago fue confirmado correctamente.</p>
            </div>
          ) : (
            codes.map((item, index) => (
              <article className="success-product-card" key={`${item.productId}-${item.code}-${index}`}>
                <div className="success-product-head">
                  <span className="success-freefire-icon">F</span>
                  <div>
                    <strong>Free Fire Diamonds Singapore</strong>
                    <span>Entrega digital</span>
                  </div>
                </div>
                <p className="success-denomination">Código de la tarjeta regalo</p>
                <div className="success-code-row">
                  <code>{item.code}</code>
                  <button onClick={() => copyCode(item.code)}>
                    {copied === item.code ? "✓ COPIADO" : "📋 COPIAR"}
                  </button>
                </div>
              </article>
            ))
          )}
        </section>

        <div className="success-confirmed">
          <span>✓</span>
          <div>
            <strong>Pago confirmado y entrega realizada</strong>
            <p>La transacción fue verificada en la red BNB Smart Chain.</p>
          </div>
        </div>

        <Link href="/" className="success-primary-button">
          🛒 VOLVER A LA TIENDA
        </Link>
      </div>
    </main>
  );
}
