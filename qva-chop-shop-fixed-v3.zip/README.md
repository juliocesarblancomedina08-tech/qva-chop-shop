# 🤖Qva🇨🇺CHOP🛒

Tienda Next.js de productos digitales con pago USDT BEP-20 y entrega automática de códigos.

## Flujo de pago

1. El cliente crea el pedido.
2. Se reserva el código digital en la base de datos.
3. La página de pago comprueba automáticamente cada 5 segundos la blockchain BNB Smart Chain.
4. El servidor busca una transferencia USDT al monedero de la tienda, valida el contrato, destinatario, importe y recibo de la transacción.
5. Tras 3 confirmaciones, el pedido pasa a `paid` y los códigos reservados pasan a `delivered`.
6. El cliente es enviado a `/success`, donde ve el estado de orden completada y recibe sus códigos.

## Variables de entorno

Configura estas variables en Vercel/tu entorno de producción:

- `DATABASE_URL`
- `BSC_RPC_URL`
- `STORE_WALLET_ADDRESS`
- `NEXT_PUBLIC_STORE_WALLET_ADDRESS`
- `USDT_BEP20_CONTRACT`

`STORE_WALLET_ADDRESS` y `USDT_BEP20_CONTRACT` deben corresponder a la red BNB Smart Chain y al contrato USDT BEP-20 que realmente utilizas.

## Importante

La entrega automática depende de que la base de datos tenga códigos con estado `available`, asociados al `productId` correcto. El servidor es quien confirma el pago; el navegador no puede marcar una orden como pagada por sí solo.
